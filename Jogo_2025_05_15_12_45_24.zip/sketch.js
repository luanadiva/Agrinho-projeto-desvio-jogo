let player;
let obstacles = [];
let score = 0;
let lives = 3;
let gameWon = false;

function setup() {
  createCanvas(400, 400);
  player = new Player();
}

function draw() {
  if (gameWon) {
    // Tela de vitória
    background(0, 255, 0); // fundo verde para vitória
    fill(255);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Vitória!", width / 2, height / 2);  // Agora a mensagem vai aparecer
    drawGrid();
    return;
  }

  background(220);

  // Atualiza e desenha o jogador
  player.update();
  player.show();

  // Gera obstáculos a cada 60 quadros
  if (frameCount % 60 === 0 && !gameWon) {
    obstacles.push(new Obstacle());
  }

  // Atualiza e desenha os obstáculos
  for (let i = obstacles.length - 1; i >= 0; i--) {
    obstacles[i].update();
    obstacles[i].show();

    // Verifica colisão
    if (obstacles[i].hits(player)) {
      lives--;
      obstacles.splice(i, 1); // Remove o obstáculo após a colisão
      if (lives <= 0) {
        resetGame();
      }
    }

    // Remove obstáculos fora da tela
    if (obstacles[i].offscreen()) {
      obstacles.splice(i, 1);
      score++;
    }
  }

  // Exibe a pontuação e vidas
  fill(0);
  textSize(20);
  text('Score: ' + score, 10, 30);
  text('Lives: ' + lives, 10, 60);

  // Verifica vitória
  if (score >= 50 && !gameWon) {
    gameWon = true;
  }

  // Se o jogador perdeu todas as vidas, reinicia o jogo
  if (lives <= 0) {
    fill(255, 0, 0);
    textSize(32);
    textAlign(CENTER, CENTER);
    text("Game Over!", width / 2, height / 2);
    drawGrid();
  }
}

// Classe do jogador
class Player {
  constructor() {
    this.x = 50;
    this.y = height / 2;
    this.size = 50;
    this.velocity = 0;
  }

  update() {
    // Movimento do jogador
    if (keyIsDown(UP_ARROW) && this.y > 0) {
      this.velocity = -5;
    } else if (keyIsDown(DOWN_ARROW) && this.y < height - this.size) {
      this.velocity = 5;
    } else {
      this.velocity = 0;
    }
    
    this.y += this.velocity;
  }

  show() {
    fill(0);
    rect(this.x, this.y, this.size, this.size);
  }
}

// Classe dos obstáculos
class Obstacle {
  constructor() {
    this.x = width;
    this.y = random(height - 50);
    this.width = 20;
    this.height = random(20, 80);
    this.speed = 5;
  }

  update() {
    this.x -= this.speed;
  }

  show() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.width, this.height);
  }

  offscreen() {
    return this.x < 0;
  }

  hits(player) {
    return (player.x < this.x + this.width && 
            player.x + player.size > this.x && 
            player.y < this.y + this.height && 
            player.y + player.size > this.y);
  }
}

// Função para resetar o jogo
function resetGame() {
  obstacles = [];
  score = 0;
  lives = 3;
  player.y = height / 2;
  frameCount = 0;
  gameWon = false;
}

// Função para desenhar a grade quadriculada
function drawGrid() {
  stroke(200);
  for (let x = 0; x < width; x += 40) {
    for (let y = 0; y < height; y += 40) {
      rect(x, y, 40, 40);
    }
  }
}